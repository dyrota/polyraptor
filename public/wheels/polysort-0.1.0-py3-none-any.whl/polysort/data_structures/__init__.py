# No additional data structures required beyond Python builtins.
